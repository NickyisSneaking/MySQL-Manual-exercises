this all the answers and database in the manual mysql it's a free source so you can edit or take the code 

JUST REMEMBER IF YOU ARE USING ONLINE COMPILER JUST REMOVE "CREATE DATABASE IF EXIST"
SOMETHING THAT ONLINE DOESN'T WANT YOU TO MODIFIED THIER DATA FROM I USE SQL ONLINE COMPILER 

NOTE: remember the database schema is in the exercise 1


