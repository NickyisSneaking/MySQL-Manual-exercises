--this only for the commands the whole table is in the exercise 1 you can the another table if you want even though its free to use
USE addressbook;

SELECT id 
FROM employee_data
WHERE age > 30;

SELECT f_name, l_name 
FROM employee_data
WHERE title = 'Web Designer';

SELECT * 
FROM employee_data 
WHERE salary <= 100000;

SELECT salary, perks 
FROM employee_data
WHERE perks > 16000;

SELECT l_name, f_name
FROM employee_data
WHERE title = 'Marketing Executive';
